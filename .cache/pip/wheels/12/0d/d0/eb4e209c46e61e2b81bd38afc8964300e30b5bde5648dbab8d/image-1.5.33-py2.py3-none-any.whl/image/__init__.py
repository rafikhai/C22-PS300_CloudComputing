VERSION = (1, 5, 33)

default_app_config = 'image.apps.ImageConfig'
